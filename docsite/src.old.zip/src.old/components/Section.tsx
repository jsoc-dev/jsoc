import type { ReactNode } from "react";

export function Section({
	id,
	title,
	subtitle,
	children,
	isHeading = false,
}: {
	id?: string;
	title: string;
	subtitle?: string;
	children?: ReactNode;
	isHeading?: boolean;
}) {
	const textSize = isHeading ? 'text-3xl' : 'text-xl';

	return (
		<section id={id} className='mb-10'>
			<h2 className={textSize + ' font-semibold mb-2'}>{title}</h2>
			{subtitle && <p className='text-md mb-4'>{subtitle}</p>}
			{children}
		</section>
	);
}

