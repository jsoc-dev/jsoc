import { Section } from '../../components/Section';
import { CodeBlock } from '../../components/CodeBlock';
import type { Framework } from '../../utils/contants';

export function OverviewGrid() {
	const react: Framework = 'react';

	return (
		<>
			<Section
				isHeading
				title='JsocGrid'
				subtitle='Dynamic Grid that requires no Rows/Columns configuration'
			/>

			{Array.from({ length: 100 }, (_, i) => i + 1).map(x =>
				<p>{x}</p>
			)}

			<Section id={react} title='React'>
				<p className='mb-4'>Importing JsocGrid</p>
				<CodeBlock language='tsx'>
					{"import { JsocGrid } from '@jsoc/react/grid'"}
				</CodeBlock>
			</Section>
		</>
	);
}
