import { OverviewGrid } from './OverviewGrid';
import { COMPONENT_MAP } from '../../utils/contants';
import { Section } from '../../components/Section';
import { Link, Route, Routes } from 'react-router';

export function CompsPage() {
	return (
		<>
			<div className='mt-14'>
				<Routes>
					<Route index element={<Components />} />
					<Route path='grid' element={<OverviewGrid />} />
				</Routes>
			</div>
		</>
	);
}

function Components() {
	const components = Object.entries(COMPONENT_MAP);

	return (
		<Section
			isHeading
			title='Components'
			subtitle='Dynamic, auto-configured  and adaptive UI components'
		>
			<div className='flex space-x-3'>
				{components.map(([key, { name, path }]) => (
					<Link className='link-button' key={key} to={path}>
						{name}
					</Link>
				))}
			</div>
		</Section>
	);
}
