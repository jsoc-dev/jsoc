import { Section } from '../../components/Section';

export function GetStartedWithVue() {
	return (
		<>
			<Section
				isHeading
				title='JSOC x Vue'
				subtitle='This page will guide you through how to use JSOC in your Vue app.'
			/>

			<Section id='installation' title='Installation'>
				JSOC for Vue will be available soon.
			</Section>
		</>
	);
}
