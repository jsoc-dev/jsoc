import { FRAMEWORK_MAP } from '../../utils/contants.ts';
import { Section } from '../../components/Section.tsx';
import { GetStartedWithAngular } from './GetStartedWithAngular.tsx';
import { GetStartedWithReact } from './GetStartedWithReact.tsx';
import { GetStartedWithVue } from './GetStartedWithVue.tsx';
import { Link, Route, Routes } from 'react-router';

export function DocsPage() {
	return (
		<>
			<div className='mt-14'>
				<Routes>
					<Route index element={<GetStarted />} />
					<Route path='angular' element={<GetStartedWithAngular />} />
					<Route path='react' element={<GetStartedWithReact />} />
					<Route path='vue' element={<GetStartedWithVue />} />
				</Routes>
			</div>
		</>
	);
}

export function GetStarted() {
	return (
		<>
			<Section
				isHeading
				title='Get Started'
				subtitle='This page will guide you through how to use JSOC in your
					desired framework.'
			/>

			<Section
				id='frameworks'
				title='Frameworks'
				subtitle='Start by selecting the framework which your app uses.'
			>
				<div className='flex space-x-3'>
					{Object.entries(FRAMEWORK_MAP).map(
						([key, { name, path }]) => (
							<Link className='link-button' key={key} to={path}>
								{name}
							</Link>
						)
					)}
				</div>
			</Section>
		</>
	);
}

export function BackButton({
	path
}: {
	path: string
}) {
	return (
		<div className=' mb-10'>
			<Link className='link-button' to={path}>
				← Back
			</Link>
		</div>
	);
}